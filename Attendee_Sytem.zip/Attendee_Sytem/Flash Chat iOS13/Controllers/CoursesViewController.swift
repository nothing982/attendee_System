//
//  CoursesViewController.swift
//  Flash Chat iOS13
//
//  Created by Admin on 31/05/2021.
//  Copyright © 2021 Angela Yu. All rights reserved.
//

import UIKit
import Firebase
class CoursesViewController: UIViewController {
    
    @IBOutlet weak var imageLabel: UIImageView!
    
    var messages: [Message] = []
    var itemAray = ["FInd Mike ", "Buy Eggs ", "Destry Demogoron"]
    var getValue: String?
    let db = Firestore.firestore()
     
    @IBOutlet weak var tableView: UITableView!
    
    @IBOutlet weak var courselabel: UILabel!
    
    @IBOutlet weak var CoursesTextLabel: UILabel!
    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
        navigationItem.hidesBackButton = true
        
        loadingFromDataBase()
    }
    

    
    
    @IBAction func logOut(_ sender: UIBarButtonItem) {
        
        do {
            try Auth.auth().signOut()
            navigationController?.popViewController(animated: true)
        } catch let signOutError as NSError {
            print("Error Signing out : %@", signOutError)
        }
    }
    
    
    
  
//    func perform(for segue: UIStoryboardSegue, sender: Any?) {
//        if segue.identifier == "CoursesToStudent" {
//            print("INSIDE THE PERFORM")
//            if let indexPath = tableView.indexPathForSelectedRow {
//                let destVC = segue.destination as! StudentViewController
//                destVC.courseName = messages[indexPath.row].body
//            }
//        }
//    }
    
    @IBAction func addCoursesButton(_ sender: UIBarButtonItem) {
        
        var textField = UITextField()
        
        let alert = UIAlertController(title: "Add new Courses", message: "", preferredStyle: .alert)
        let action = UIAlertAction(title: "Add Course", style: .default) { (action) in
            print(textField.text)
            self.getValue = textField.text!
            print(self.getValue!)
            self.itemAray.append(textField.text!)
            self.AddingDataToDatabase()
            
            self.tableView.reloadData()
            
        }
            
        alert.addTextField { (alertTextField) in
            alertTextField.placeholder = "Create new Item"
            textField = alertTextField
            print(alertTextField.text)
            print("Now")
        }
        
        alert.addAction(action)
        present(alert, animated: true, completion: nil)
    }
    
    func AddingDataToDatabase() {
        
        if let messageBody = getValue, let messageSender =
            Auth.auth().currentUser?.email {
            
            db.collection(K.FStore.collectionName).addDocument(data: [K.FStore.senderField : messageSender,
                                                                      K.FStore.bodyField:messageBody
            ])
        }
    }
    
    func loadingFromDataBase(){
        
        db.collection(K.FStore.collectionName).addSnapshotListener {(querySnapshot, error) in
            
        
            self.messages = []
        
        if let e = error {
            print("There was an issue in getting the data from Firestore, \(e)")
            
        }
        else {
            if let snapshotDocuments = querySnapshot?.documents {
                for doc in snapshotDocuments {
                    let data = doc.data()
                    
                    //this is basically data sender
                    
                    let user = Auth.auth().currentUser
                    
                    
                    
                    
                    if let messageSender = data[K.FStore.senderField] as? String ,
                       
                       let messagebody = data[K.FStore.bodyField]
                    {
                        
                        var email: String? = nil
                        
                        if let user = user {
                              let uid = user.uid
                             email = user.email!
                            print( " UID IS EQUAL TO \(uid)", "EMIAL OF CURRENT USER IS \(email)")
                        }
                        if(email == messageSender)
                        {
                        let newMessage = Message(sender: messageSender, body: messagebody as! String)
                        //adds the retreived data to the message array
                        self.messages.append(newMessage)
                        
                        // use this in a closure
                        DispatchQueue.main.async {
                            self.tableView.reloadData()
                        }
                    }
                        
                    }
                }
            }
        }
        }
    }

}
extension CoursesViewController: UITableViewDataSource, UITableViewDelegate {
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return messages.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "CoursesCell", for: indexPath)
        
        if(indexPath.row > messages.count - 1){
            return UITableViewCell()
        } else {
            cell.textLabel?.textColor = .white
            cell.textLabel?.textAlignment = .center
            cell.textLabel?.font = .boldSystemFont(ofSize: 40)
        cell.textLabel?.text = messages[indexPath.row].body
        
        return cell
        }
    }
    
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
       // print(itemAray[indexPath.row])
        tableView.deselectRow(at: indexPath, animated: true)
        var value = messages[indexPath.row].body
//        func performSegue(for segue: UIStoryboardSegue, sender: Any?) {
//            let destVS: StudentViewController = segue.destination as! StudentViewController
//            destVS.courseName = value
//        }
        
        let vc = storyboard?.instantiateViewController(identifier: "StudentViewController") as? StudentViewController
        vc?.courseName = messages[indexPath.row].body
        
        self.navigationController?.pushViewController(vc!, animated: true)
       // performSegue(withIdentifier: "CoursesToStudent", sender: nil)
    
        
    }
    
    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        return 114
    }
    
    
    
  
}
