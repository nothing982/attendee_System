//
//  StudentName.swift
//  Flash Chat iOS13
//
//  Created by Admin on 31/05/2021.
//  Copyright © 2021 Angela Yu. All rights reserved.
//

import Foundation


struct StudentName {
    let teacherEmail: String
    let courseName: String
    let studentName: String
}
