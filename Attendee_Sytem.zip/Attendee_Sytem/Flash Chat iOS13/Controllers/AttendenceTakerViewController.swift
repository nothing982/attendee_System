//
//  AttendenceTakerViewController.swift
//  Flash Chat iOS13
//
//  Created by Admin on 31/05/2021.
//  Copyright © 2021 Angela Yu. All rights reserved.
//

import UIKit

class AttendenceTakerViewController: UIViewController {

    @IBOutlet weak var txtDate: UITextField!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        txtDate.delegate = self
    }

}

extension AttendenceTakerViewController : UITextFieldDelegate {
    func textFieldDidEndEditing(_ textField: UITextField) {
        self.openDatePicker()
    }
}

extension AttendenceTakerViewController {
    
    func  openDatePicker(){
      
    let datePicker = UIDatePicker()
      
        datePicker.datePickerMode = .date
        datePicker.addTarget(self, action: #selector(self.datePickerHandler(datePicker:)), for: .valueChanged)
        
        txtDate.inputView = datePicker
        
        let toolbar = UIToolbar(frame: CGRect(x: 0, y: 0,width:self.view.frame.width, height: 44))
        
        let cancelBtn = UIBarButtonItem(title: "Cancel", style: .plain, target: self, action: #selector(self.cancelBtnClicked))
        
        let doneBtn = UIBarButtonItem(title: "done", style: .plain, target: nil, action: #selector(doneBtnClicked))
        
        let flexibleBtn = UIBarButtonItem(barButtonSystemItem: .flexibleSpace, target: nil, action: nil)
        
        toolbar.setItems([cancelBtn, flexibleBtn,doneBtn], animated: true)
        txtDate.inputAccessoryView = toolbar
        
        
        
    }
    
    @objc func cancelBtnClicked(){
        
        txtDate.resignFirstResponder()
    }
    
    @objc func doneBtnClicked(){
        if let datePicker = txtDate.inputView as? UIDatePicker {
            let dateFormatter = DateFormatter()
            dateFormatter.dateStyle = .medium
            txtDate.text = dateFormatter.string(from: datePicker.date)
            print(datePicker.date)
            
        }
        
        txtDate.resignFirstResponder()
    }
    
    @objc func datePickerHandler(datePicker: UIDatePicker){
        print(datePicker.date)
    }
}
