//
//  AttendenvceViewController.swift
//  Flash Chat iOS13
//
//  Created by Admin on 31/05/2021.
//  Copyright © 2021 Angela Yu. All rights reserved.
//

import UIKit
import Firebase


class AttendenvceViewController: UIViewController, UITextFieldDelegate {

    
    var attendenceArray = [String]()
    
    @IBOutlet weak var tableViewAttendee: UITableView!
    
    @IBOutlet weak var dateTextField: UITextField!
    var coursesName: String?
    var emailOfTeacher: String = ""
    var date:String?
  //  @IBOutlet weak var tableView: UITableView!
    var messages: [StudentName] = []
    var itemAray = ["FInd Mike ", "Buy Eggs ", "Destry Demogoron"]
    var getValue: String?
    let db = Firestore.firestore()
    
    override func viewDidLoad() {
        super.viewDidLoad()
        tableViewAttendee.delegate = self
        tableViewAttendee.dataSource = self
        dateTextField.delegate = self
         //date = dateTextField.text
        // Do any additional setup after loading the view.
        loadingFromDataBase()
        
    }
    
    
    @IBAction func EnterDate(_ sender: UIButton) {
        
        date = dateTextField.text!
        print(date!)
        
        for list in attendenceArray {
            
            getValue = list
            AddingDataToDatabase()
            navigationController?.popViewController(animated: true)
        }
        
        
    }
    
    func AddingDataToDatabase() {
        
        print("IN ADDING TO DATABASE")
        if let messageBody = coursesName, let messageSender =
            Auth.auth().currentUser?.email ,let student = getValue, let date = dateTextField.text {
            
            db.collection(K.FStore.studentAttendenceList).addDocument(data: [K.FStore.senderField : messageSender,
                                                                             K.FStore.bodyField:messageBody, K.FStore.AttendenceList: student, K.FStore.dateField: date
            ])
        }else {
            print("DATA BASE NOT ACCESS ")
        }
    }
//
 
    
    func loadingFromDataBase(){

        db.collection(K.FStore.studentCollectionName).addSnapshotListener {(querySnapshot, error) in

            print("INSIDE THE LOADING DATABASE")
            self.messages = []

        if let e = error {
            print("There was an issue in getting the data from Firestore, \(e)")

        }
        else {
            if let snapshotDocuments = querySnapshot?.documents {
                for doc in snapshotDocuments {
                    let data = doc.data()

                    //this is basically data sender

                    let user = Auth.auth().currentUser
                    print(user)



                    if let messageSender = data[K.FStore.senderField] as? String ,

                       let messagebody = data[K.FStore.bodyField], let student = data[K.FStore.studentName]
                    {

                        var email: String? = nil

                        if let user = user {
                              let uid = user.uid
                             email = user.email!
                            print( "IN STUDENT VIEW  UID IS EQUAL TO \(uid)", "EMIAL OF CURRENT USER IS \(email)")
                        }
                        if(email == messageSender){ if (self.coursesName == messagebody as! String) {
                            do {
                            let newMessage = StudentName(teacherEmail: messageSender, courseName: messagebody as! String , studentName: student as! String)
                        //adds the retreived data to the message array
                        self.messages.append(newMessage)

                        // use this in a closure
                        DispatchQueue.main.async {
                            self.tableViewAttendee.reloadData()
                        }
                    }
                        }
                        
                        }
                    }
                }
            }
        }
        }
    }
    

}

extension AttendenvceViewController: UITableViewDataSource, UITableViewDelegate {
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        
        return messages.count
    }
    
 

    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "AttendeeStudent", for: indexPath)

        if(indexPath.row > messages.count - 1){
            return UITableViewCell()
        } else {
            cell.textLabel?.font = .boldSystemFont(ofSize: 20)
        cell.textLabel?.text = messages[indexPath.row].studentName

        return cell
        }
    }

    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        //print(itemAray[indexPath.row])
       // tableView.deselectRow(at: indexPath, animated: true)
        
        tableView.cellForRow(at: indexPath)?.accessoryType = .checkmark
        
        tableView.deselectRow(at: indexPath, animated: true)

        print(messages[indexPath.row].studentName)
        getValue = messages[indexPath.row].studentName
        
        attendenceArray.append(getValue ?? "Car")
        
        //AddingDataToDatabase()
        
        

    }
    
    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        return 60
    }


}
