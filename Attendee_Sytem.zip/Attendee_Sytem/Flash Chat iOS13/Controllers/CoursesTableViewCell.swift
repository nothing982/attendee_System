//
//  CoursesTableViewCell.swift
//  Flash Chat iOS13
//
//  Created by Admin on 31/05/2021.
//  Copyright © 2021 Angela Yu. All rights reserved.
//

import UIKit

class CoursesTableViewCell: UITableViewCell {

    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }

    
    
  

}
