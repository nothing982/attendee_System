//
//  AttendenceCheckerViewController.swift
//  Flash Chat iOS13
//
//  Created by Admin on 01/06/2021.
//  Copyright © 2021 Angela Yu. All rights reserved.
//

import UIKit
import Firebase
class AttendenceCheckerViewController: UIViewController, UITextFieldDelegate {
    var date:String?
    var coursesName: String?
    @IBOutlet weak var AttendenceListView: UITableView!
    @IBOutlet weak var dateTextField: UITextField!
    var messages: [AttendenceList] = []
    var db = Firestore.firestore()
    override func viewDidLoad() {
        super.viewDidLoad()
        dateTextField.delegate = self
        // Do any additional setup after loading the view.
    }
    

    
    @IBAction func enterButtonPressed(_ sender: UIButton) {
        date = dateTextField.text!
        
        loadingFromDataBase()
        
        
    }
    
    func loadingFromDataBase(){

        db.collection(K.FStore.studentAttendenceList).addSnapshotListener {(querySnapshot, error) in

            print("INSIDE THE LOADING DATABASE")
            self.messages = []

        if let e = error {
            print("There was an issue in getting the data from Firestore, \(e)")

        }
        else {
            if let snapshotDocuments = querySnapshot?.documents {
                for doc in snapshotDocuments {
                    let data = doc.data()
                  //  print(data)
                    //this is basically data sender

                    let user = Auth.auth().currentUser
//                    print(user)


                    print(self.date!)
                    
                    if let messageSender = data[K.FStore.senderField] as? String,

                       let messagebody = data[K.FStore.bodyField], let student = data[K.FStore.AttendenceList],
                       let date1 = data[K.FStore.dateField]
                    {
                            print("inside let")
                        var email: String? = nil

                        if let user = user {
                              let uid = user.uid
                             email = user.email!
                            print("WE ARE IN ATTENDENCE CHECKING LIST ")
                            print( "UID IS EQUAL TO \(uid)", "EMIAL OF CURRENT USER IS \(email)")
                        }
                        
                        
                        if(email == messageSender){
                            print("EMAIIL IS RIGHT")
                            if (self.coursesName == messagebody as! String) {
                            print("COURSES NAME IS RIGHT ")
                            if(self.date == date1 as! String ) {
                                print("DateChecker is right")
                            do {
                                let newMessage = AttendenceList(teacherEmail: messageSender, courseName: messagebody as! String , studentName: student as! String,Date1: self.date ?? "CHECK")
                        //adds the retreived data to the message array
                        self.messages.append(newMessage)

                        // use this in a closure
                        DispatchQueue.main.async {
                            self.AttendenceListView.reloadData()
                        }
                    }
                            }else {
                                print("Date NOT MATCH ")
                            }
                        }else{
                            print("EMAIL IS NOT MATCH")
                        }
                        
                        }
                    else {
                        print("DOES NOT DO THE RIGHT THING")
                    }
                }
            }
        }
        }
    }
    
}
}
extension AttendenceCheckerViewController: UITableViewDataSource, UITableViewDelegate {
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        
        return messages.count
    }
    
 

    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "AttendenceSheet", for: indexPath)

        if(indexPath.row > messages.count - 1){
            return UITableViewCell()
        } else {
            cell.textLabel?.font = .boldSystemFont(ofSize: 20)
        cell.textLabel?.text = messages[indexPath.row].studentName

        return cell
        }
    }

    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        //print(itemAray[indexPath.row])
       // tableView.deselectRow(at: indexPath, animated: true)
        
       // tableView.cellForRow(at: indexPath)?.accessoryType = .checkmark
        
        tableView.deselectRow(at: indexPath, animated: true)

        print(messages[indexPath.row].studentName)
        
        
        //AddingDataToDatabase()
        
        

    }
    
    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        return 60
    }


}
