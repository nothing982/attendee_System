//
//  StudentViewController.swift
//  Flash Chat iOS13
//
//  Created by Admin on 31/05/2021.
//  Copyright © 2021 Angela Yu. All rights reserved.
//

import UIKit
import Firebase
class StudentViewController: UIViewController {
    
    var courseName: String?
    var emailOfTeacher: String = ""
    
  //  @IBOutlet weak var tableView: UITableView!
    var messages: [StudentName] = []
    var itemAray = ["FInd Mike ", "Buy Eggs ", "Destry Demogoron"]
    var getValue: String?
    let db = Firestore.firestore()
     
    
    @IBOutlet weak var StudentTableView: UITableView!
    
    @IBOutlet weak var CoursesTextLabel: UILabel!
    
    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
       // navigationItem.hidesBackButton = true
        print(courseName)
        
        //StudentTableView.register(UINib(nibName: K.cellNibName, bundle: nil), forCellReuseIdentifier: K.StudentCellIdentifier)
        
        loadingFromDataBase()
        
        
        
    }
    
    
    @IBAction func SeeAttendenceButtonPressed(_ sender: UIButton) {
        
        let vc = storyboard?.instantiateViewController(identifier: "AttendenceCheckerViewController") as? AttendenceCheckerViewController
        vc?.coursesName = courseName
        
        self.navigationController?.pushViewController(vc!, animated: true)
    }
    
    
    @IBAction func DoAttendenceButtonPressed(_ sender: Any) {
        let vc = storyboard?.instantiateViewController(identifier: "AttendenceTakerViewController") as? AttendenvceViewController
        vc?.coursesName = courseName
        
        self.navigationController?.pushViewController(vc!, animated: true)
        
    }
    
    @IBAction func logOut(_ sender: UIBarButtonItem) {
        
        do {
            try Auth.auth().signOut()
            navigationController?.popViewController(animated: true)
        } catch let signOutError as NSError {
            print("Error Signing out : %@", signOutError)
        }
    }
    
    
    @IBAction func addStudent(_ sender: UIBarButtonItem) {
        
        var textField = UITextField()

        let alert = UIAlertController(title: "Add new Student", message: "", preferredStyle: .alert)
        let action = UIAlertAction(title: "Add Course", style: .default) { (action) in
            print(textField.text)
            self.getValue = textField.text!
            print(self.getValue!)
            self.itemAray.append(textField.text!)
            self.AddingDataToDatabase()
            

        }

        alert.addTextField { (alertTextField) in
            alertTextField.placeholder = "Create new Item"
            textField = alertTextField
            print(alertTextField.text)
            print("Now")
        }

        alert.addAction(action)
        self.StudentTableView.reloadData()
        

        self.StudentTableView.reloadData()
        present(alert, animated: true, completion: nil)
    }
   


//


    
//
    func AddingDataToDatabase() {
print("IN ADDING TO DATABASE")
        if let messageBody = courseName, let messageSender =
            Auth.auth().currentUser?.email ,let student = getValue {
            
            db.collection(K.FStore.studentCollectionName).addDocument(data: [K.FStore.senderField : messageSender,
                                                                             K.FStore.bodyField:messageBody, K.FStore.studentName: student
            ])
        }else {
            print("DATA BASE NOT ACCESS ")
        }
    }
//
    func loadingFromDataBase(){

        db.collection(K.FStore.studentCollectionName).addSnapshotListener {(querySnapshot, error) in

            print("INSIDE THE LOADING DATABASE")
            self.messages = []

        if let e = error {
            print("There was an issue in getting the data from Firestore, \(e)")

        }
        else {
            if let snapshotDocuments = querySnapshot?.documents {
                for doc in snapshotDocuments {
                    let data = doc.data()

                    //this is basically data sender

                    let user = Auth.auth().currentUser




                    if let messageSender = data[K.FStore.senderField] as? String ,

                       let messagebody = data[K.FStore.bodyField], let student = data[K.FStore.studentName]
                    {

                        var email: String? = nil

                        if let user = user {
                              let uid = user.uid
                             email = user.email!
                            print( "IN STUDENT VIEW  UID IS EQUAL TO \(uid)", "EMIAL OF CURRENT USER IS \(email)")
                        }
                        if(email == messageSender){ if (self.courseName == messagebody as! String) {
                            do {
                            let newMessage = StudentName(teacherEmail: messageSender, courseName: messagebody as! String , studentName: student as! String)
                        //adds the retreived data to the message array
                        self.messages.append(newMessage)

                        // use this in a closure
                        DispatchQueue.main.async {
                            self.StudentTableView.reloadData()
                        }
                    }
                        }
                        
                        }
                    }
                }
            }
        }
        }
    }

}
    

extension StudentViewController: UITableViewDataSource, UITableViewDelegate {
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        
        return messages.count
    }
    
 

    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "StudentCell", for: indexPath)

        if(indexPath.row > messages.count - 1){
            return UITableViewCell()
        } else {
            cell.textLabel?.font = .boldSystemFont(ofSize: 20)
        cell.textLabel?.text = messages[indexPath.row].studentName

        return cell
        }
    }

    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        //print(itemAray[indexPath.row])
        tableView.deselectRow(at: indexPath, animated: true)



    }
    
    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        return 60
    }


}


