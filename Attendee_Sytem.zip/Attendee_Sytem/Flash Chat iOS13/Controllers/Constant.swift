//
//  Constant.swift
//  Flash Chat iOS13
//
//  Created by Admin on 31/05/2021.
//  Copyright © 2021 Angela Yu. All rights reserved.
//

import Foundation


struct K {
    static let CoursesCellIdentifier = "CoursesCell"
    static let StudentCellIdentifier = "StudentCell"
    static let cellIdentifier = "ReusableCell"
    static let cellNibName = "MessageCell"
    static let registerSegue = "RegisterToChat"
    static let loginSegue = "LoginToChat"
    
    struct BrandColors {
        static let purple = "BrandPurple"
        static let lightPurple = "BrandLightPurple"
        static let blue = "BrandBlue"
        static let lighBlue = "BrandLightBlue"
    }
    
    struct FStore {
        static let collectionName = "Courses"
        static let studentCollectionName = "Student"
        static let studentAttendenceList = "studentAttendenceList"
        static let senderField = "UserName"
        static let bodyField = "courseName"
        static let dateField = "Date"
        static let studentName = "Name"
        static let AttendenceList = "AttendenceList"
        
        
       // static let teacherEmail = "teacherEmail"
        static let UserName = "userName"
        static let coursesName = "courseName"
        
        
    }
}
